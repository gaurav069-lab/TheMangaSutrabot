# MangaSutra Bot

## Setup
1. Install Python 3.8+
2. `pip install -r requirements.txt`
3. Set BOT_TOKEN in environment variables or directly in bot.py
4. Run `python bot.py`

## Features
- VIP Subscription System
- Comic Purchases
- Payment Verification